<?php

define('DB_NAME', 'php_retrofit_crud_delaroy_studio');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

$db = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if ($db == false) {
    echo "Unable to connect";
}

?>