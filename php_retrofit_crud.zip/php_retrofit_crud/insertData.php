<?php

require_once "db_function.php";
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Getting post data
$name = $_POST['name'];
$age = $_POST['age'];
$mobile= $_POST['mobile'];
$email = $_POST['email'];

if (isset($_POST['name']) && isset($_POST['age']) && isset($_POST['mobile']) && isset($_POST['email'])) {
    $result = insertData($name, $age, $mobile, $email);
    if ($result) {
        $response['success'] = 1;
        $response['message'] = "User data inserted...";
        echo json_encode($response);
    }else{
        $response['success'] = 0;
        $response['message'] = "Oops! An error occurred.";
        echo json_encode($response);
    }
}else{
    $response['success'] = 0;
    $response['message'] = "Required fields are missing.";
    echo json_encode($response);
}

}else {
    $response['success'] = 0;
    $response['message'] = "Invalid Request";
    echo json_encode($response);
}

